# Copyright 1999-2026 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2

EAPI=8

DESCRIPTION="Scans the shares of a SMB/NetBIOS network"
HOMEPAGE="http://nmbscan.g76r.eu/"
SRC_URI="http://nmbscan.g76r.eu/down/${P}.tar.gz"

LICENSE="GPL-2"
SLOT="0"
KEYWORDS="~alpha amd64 arm ~hppa ~ppc ppc64 ~sparc x86"

RDEPEND="
	app-alternatives/awk
	net-dns/bind
	net-fs/samba
	net-misc/iputils
	sys-apps/net-tools
"

S=${WORKDIR}
PATCHES=( "${FILESDIR}"/${P}-head.diff )

src_compile() { :; }

src_install() {
	dobin nmbscan
}
