# Copyright 1999-2026 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2

EAPI=8

inherit toolchain-funcs

# sslscan builds against a static openssl library to allow weak ciphers
# to be enabled so that they can be tested.
OPENSSL_RELEASE_TAG="openssl-3.6.3"

DESCRIPTION="Fast SSL configuration scanner"
HOMEPAGE="https://github.com/rbsec/sslscan"
SRC_URI="https://github.com/rbsec/sslscan/archive/${PV}.tar.gz -> ${P}.tar.gz
		https://github.com/openssl/openssl/releases/download/${OPENSSL_RELEASE_TAG}/${OPENSSL_RELEASE_TAG}.tar.gz"

LICENSE="GPL-3"
SLOT="0"
KEYWORDS="~amd64 ~arm64 ~ppc64 ~x86"

# Requires a docker environment
RESTRICT="test"

PATCHES=(
	"${FILESDIR}/${PN}-2.2.0-use-distfile-openssl.patch"
	"${FILESDIR}/${PN}-2.2.2-ignore-sigpipe.patch"
	"${FILESDIR}/${PN}-2.2.2-version-newline.patch"
)

src_prepare() {
	ln -s ../${OPENSSL_RELEASE_TAG} openssl || die
	touch .openssl_is_fresh || die

	# Don't clobber toolchain defaults
	sed -i 's/ -D_FORTIFY_SOURCE=2/ /' Makefile || die

	# Copied from dev-libs/openssl
	# allow openssl to be cross-compiled
	cp "${FILESDIR}"/gentoo.config-1.0.4 gentoo.config || die
	chmod a+rx gentoo.config || die

	default
}

src_configure() {
	# Copied from dev-libs/openssl
	unset APPS #197996
	unset SCRIPTS #312551
	unset CROSS_COMPILE #311473

	tc-export CC AR RANLIB RC

	local sslout=$(./gentoo.config)
	einfo "Use configuration ${sslout:-(openssl knows best)}"
	local config="Configure"
	[[ -z ${sslout} ]] && config="config"

	# Clean out hardcoded flags that openssl uses
	local DEFAULT_CFLAGS=$(grep ^CFLAGS= Makefile | LC_ALL=C sed \
		-e 's:^CFLAGS=::' \
		-e 's:\(^\| \)-fomit-frame-pointer::g' \
		-e 's:\(^\| \)-O[^ ]*::g' \
		-e 's:\(^\| \)-march=[^ ]*::g' \
		-e 's:\(^\| \)-mcpu=[^ ]*::g' \
		-e 's:\(^\| \)-m[^ ]*::g' \
		-e 's:^ *::' \
		-e 's: *$::' \
		-e 's: \+: :g' \
		-e 's:\\:\\\\:g'
	)

	# Now insert clean default flags with user flags
	sed -i \
		-e "/^CFLAGS=/s|=.*|=${DEFAULT_CFLAGS} ${CFLAGS}|" \
		-e "/^LDFLAGS=/s|=[[:space:]]*$|=${LDFLAGS}|" \
		Makefile || die
}

src_compile() {
	emake static
}

src_install() {
	DESTDIR="${D}" emake install

	dodoc Changelog README.md
}
