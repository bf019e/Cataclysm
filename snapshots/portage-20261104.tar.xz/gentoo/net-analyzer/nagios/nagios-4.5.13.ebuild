# Copyright 1999-2026 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2

EAPI=8

DESCRIPTION="The Nagios metapackage"
HOMEPAGE="https://www.nagios.org/"

LICENSE="metapackage"
SLOT="0"
KEYWORDS="~alpha amd64 ~arm ~arm64 ~ppc ppc64 ~riscv ~sparc x86"

RDEPEND="~net-analyzer/nagios-core-${PV}
	|| ( net-analyzer/nagios-plugins net-analyzer/monitoring-plugins )"
