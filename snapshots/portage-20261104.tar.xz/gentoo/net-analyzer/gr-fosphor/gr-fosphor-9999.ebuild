# Copyright 1999-2026 Gentoo Authors
# Distributed under the terms of the GNU General Public License v2

EAPI=8

PYTHON_COMPAT=( python3_{12..14} )

inherit cmake python-single-r1

DESCRIPTION="gnuradio fosphor block (GPU spectrum display)"
HOMEPAGE="https://sdr.osmocom.org/trac/wiki/fosphor"

if [[ ${PV} == *9999* ]]; then
	inherit git-r3
	#EGIT_REPO_URI="https://github.com/osmocom/${PN}.git"
	EGIT_REPO_URI="https://github.com/ZeroChaos-/${PN}.git"
else
	COMMIT="662577bb1969fdd9363ff6a574c47af54f1bb607"
	#SRC_URI="https://github.com/osmocom/gr-fosphor/archive/${COMMIT}.tar.gz -> ${P}.tar.gz"
	SRC_URI="https://github.com/ZeroChaos-/${PN}/archive/${COMMIT}.tar.gz -> ${P}.gh.tar.gz"
	S="${WORKDIR}/${PN}-${COMMIT}"
	KEYWORDS="~amd64 ~x86"
fi

LICENSE="GPL-3+"
SLOT="0"
IUSE="doc +glfw"
REQUIRED_USE="${PYTHON_REQUIRED_USE}"

# libfmt:= because the spdlog symbols we link against embed fmt's ABI
RDEPEND="${PYTHON_DEPS}
	dev-libs/boost:=
	dev-libs/libfmt:=
	dev-libs/spdlog:=
	media-libs/freetype
	media-libs/libglvnd[X]
	>=net-wireless/gnuradio-3.9:0=[${PYTHON_SINGLE_USEDEP}]
	virtual/opencl
	$(python_gen_cond_dep 'dev-python/numpy[${PYTHON_USEDEP}]')
	glfw? ( >=media-libs/glfw-3 )
"
DEPEND="${RDEPEND}
	dev-libs/gmp
	dev-util/opencl-headers
	sci-libs/volk
"
BDEPEND="
	${PYTHON_DEPS}
	$(python_gen_cond_dep 'dev-python/pybind11[${PYTHON_USEDEP}]')
	virtual/pkgconfig
	doc? ( app-text/doxygen )
"

src_prepare() {
	cmake_src_prepare

	# adapt python bindings to use flags
	use glfw || sed -i -e "s#bind_glfw_sink_c(m)##" \
		python/bindings/python_bindings.cc || die
	sed -i -e "s#bind_qt_sink_c(m)##" \
		python/bindings/python_bindings.cc || die
}

src_configure() {
	# tries to run OpenCL test program, but failing doesn't hurt
	addpredict /dev/dri

	local mycmakeargs=(
		-DENABLE_DEFAULT=OFF
		-DENABLE_DOXYGEN="$(usex doc)"
		-DENABLE_GLFW="$(usex glfw)"
		-DENABLE_QT=OFF # bug #961742
		-DENABLE_PYTHON=ON
	)
	cmake_src_configure
}

src_install() {
	cmake_src_install
	find "${D}" -name '*.py[oc]' -delete || die
	python_optimize
}
